def is_leap_year(input_year):
    if input_year % 4 == 0:
        if input_year % 100 == 0:
            if input_year % 400 == 0:
                return f"{input_year} - leap year"
            else:
                return f"{input_year} - not a leap year"
        else:
            return f"{input_year} - leap year"
    else:
        return f"{input_year} - not a leap year"

year = int(input(""))
result = is_leap_year(year)

print(result)

    
